class Person {
  constructor(name, age, gender, interests) {
    this.name = name;
    this.age = age;
    this.gender = gender;
    this.interests = interests;
  }

  bio() {
    const { name, age, interests } = this;

    console.log(
      `${name} is ${age} years old. They like ${interests.join(', ')}`
    );
  }

  greeting() {
    console.log(`Hi! I'm ${this.name}`);
  }
}

const person1 = new Person('Bob Smith', 32, 'male', ['music', 'programming']);

const person2 = new Person('Emmanuel Hernandez', 22, 'male', [
  'music',
  'programming',
]);

person1.bio();
person2.bio();
