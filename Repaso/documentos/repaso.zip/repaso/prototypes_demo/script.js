Array.prototype.pop = function () {
  console.log('Hello, World!');
};

class Person {
  constructor(name, age, gender, interests) {
    this.name = name;
    this.age = age;
    this.gender = gender;
    this.interests = interests;
  }

  bio() {
    const { name, age, interests } = this;

    console.log(
      `${name} is ${age} years old. They like ${interests.join(', ')}`
    );
  }

  greeting() {
    console.log(`Hi! I'm ${this.name}`);
  }
}

Person.prototype.toString = function () {
  return 'Soy una persona...';
};

const person1 = new Person('Bob Smith', 32, 'male', ['music', 'programming']);

const person2 = new Person('Emmanuel Hernandez', 22, 'male', [
  'music',
  'programming',
]);

person1.greeting();
person2.greeting();

console.log(person1.greet === person2.greet);

console.log('Person 1: ' + person1);
console.log('Person 2: ' + person2);
