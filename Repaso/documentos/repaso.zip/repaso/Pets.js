class Pet {
  constructor(name, age, color) {
    this.name = name;
    this.age = age;
    this.color = color;
  }

  eat() {
    console.log(`${this.name} is eating!`);
  }
}

class Dog extends Pet {
  constructor(name, age, color, breed) {
    super(name, age, color);
    this.breed = breed;
  }

  bark() {
    console.log(`${this.name} says WOOF!`);
  }
}

class Cat extends Pet {
  meow() {
    console.log(`${this.name} says MEOOW!`);
  }
}

const pet1 = new Dog('Rocko', 6, 'White', 'Pitbull');
const pet2 = new Cat('Osiris', 2, 'Black');

pet1.bark();
pet1.eat();
console.log(pet1.breed);

pet2.meow();
pet2.eat();
